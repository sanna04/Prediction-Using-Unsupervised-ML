# Prediction-Using-Unsupervised-ML
Predicted the optimal number of clusters using elbow method
